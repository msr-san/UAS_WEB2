<?php  
unset($_SESSION['status']);
header("location:index.php");
?>