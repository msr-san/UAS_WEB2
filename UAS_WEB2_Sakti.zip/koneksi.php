<?php 
$host = "localhost";
$username = "root";
$pass = "";
$database = "uas";

$db = mysqli_connect("$host","$username","$pass","$database");

?>